#include "Core/ProgramInterface.h"

class FileSimProgram : public Program {
    void setup_impl() override {

    }

    void loop_impl() override {

    }

};